# Change log for esp-face

## 0.1.0
Initial commit, esp-face appear in the world.

## 0.2.0
Make face detection and recognition forward open source.
Refactor some codes.

## 0.3.0
Add flash function to enroll face id.

## 0.3.1
Make aligned face easier to pass to recognition part.

## 0.3.2
Change model from RGB to BGR
